//
//  RiChangXinLiNetManager.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "RiChangXinLiXueModel.h"
#import "YongHuTuiJianRBModel.h"
#import "DianYingRiBaoModel.h"
@interface RiChangXinLiNetManager : BaseNetManager
/** 日常心里学 */
+(id)getRiChangXinLiXueStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle;
/** 用户推荐日报 */
+(id)getYongHuTuiJianRBStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle;
/** 电影日报 */
+(id)getDianYingRiBaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle;
/** 不许无聊 */
+(id)getBuXuWuLiaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle;
/** 设计日报 */
+(id)getSheJiRiBaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle;
@end
