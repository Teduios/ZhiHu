//
//  RiChangXinLiNetManager.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RiChangXinLiNetManager.h"

@implementation RiChangXinLiNetManager
/** 日常心里学 */
+(id)getRiChangXinLiXueStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle{
    NSString *path = @"http://news-at.zhihu.com/api/4/theme/";
    NSString *path2 = [path stringByAppendingString:str];
    return [self GET:path2 parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([RiChangXinLiXueModel objectWithKeyValues:responseObj],error);
    }];
}
/** 用户推荐日报 */
+(id)getYongHuTuiJianRBStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle{
    NSString *path = @"http://news-at.zhihu.com/api/4/theme/";
    NSString *path2 = [path stringByAppendingString:str];
    return [self GET:path2 parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([YongHuTuiJianRBModel objectWithKeyValues:responseObj],error);
    }];
}
/** 电影日报 */
+(id)getDianYingRiBaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle{
    NSString *path = @"http://news-at.zhihu.com/api/4/theme/";
    NSString *path2 = [path stringByAppendingString:str];
    return [self GET:path2 parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([DianYingRiBaoModel objectWithKeyValues:responseObj],error);
    }];
}
/** 不许无聊 */
+(id)getBuXuWuLiaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle{
    NSString *path = @"http://news-at.zhihu.com/api/4/theme/";
    NSString *path2 = [path stringByAppendingString:str];
    return [self GET:path2 parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([DianYingRiBaoModel objectWithKeyValues:responseObj],error);
    }];
}
/** 设计日报 */
+(id)getSheJiRiBaoStr:(NSString *)str CompletionHandle:(void(^)(id model,NSError *error))completionHandle{
    NSString *path = @"http://news-at.zhihu.com/api/4/theme/";
    NSString *path2 = [path stringByAppendingString:str];
    return [self GET:path2 parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([DianYingRiBaoModel objectWithKeyValues:responseObj],error);
    }];
}
@end
