//
//  YongHuTuiJianRBModel.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "YongHuTuiJianRBModel.h"

@implementation YongHuTuiJianRBModel


+ (NSDictionary *)objectClassInArray{
    return @{@"stories" : [YongHuTuiJianRBStoriesModel class], @"editors" : [YongHuTuiJianRBEditorsModel class]};
}
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"desc":@"description"};
}
@end
@implementation YongHuTuiJianRBStoriesModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation YongHuTuiJianRBEditorsModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


