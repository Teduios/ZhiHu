//
//  RiChangXinLiXueModel.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class RCXLXStoriesModel;
@interface RiChangXinLiXueModel : BaseModel

@property (nonatomic, assign) NSInteger color;

@property (nonatomic, strong) NSArray<RCXLXStoriesModel *> *stories;

@property (nonatomic, copy) NSString *image_source;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *background;

@property (nonatomic, copy) NSString *name;

@end
@interface RCXLXStoriesModel : NSObject

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSArray *images;

@end

