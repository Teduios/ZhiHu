//
//  YongHuTuiJianRBModel.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class YongHuTuiJianRBStoriesModel,YongHuTuiJianRBEditorsModel;
@interface YongHuTuiJianRBModel : BaseModel

@property (nonatomic, assign) NSInteger color;

@property (nonatomic, strong) NSArray<YongHuTuiJianRBStoriesModel *> *stories;

@property (nonatomic, copy) NSString *image_source;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, strong) NSArray<YongHuTuiJianRBEditorsModel *> *editors;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *background;

@property (nonatomic, copy) NSString *name;

@end
@interface YongHuTuiJianRBStoriesModel : NSObject

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSArray *images;

@end

@interface YongHuTuiJianRBEditorsModel : NSObject

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *name;

@end

