//
//  RiChangXinLiXueModel.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RiChangXinLiXueModel.h"

@implementation RiChangXinLiXueModel


+ (NSDictionary *)objectClassInArray{
    return @{@"stories" : [RCXLXStoriesModel class]};
}
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"desc":@"description"};
}
@end
@implementation RCXLXStoriesModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


