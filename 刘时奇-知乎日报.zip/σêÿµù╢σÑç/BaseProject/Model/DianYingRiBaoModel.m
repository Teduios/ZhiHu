//
//  DianYingRiBaoModel.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DianYingRiBaoModel.h"

@implementation DianYingRiBaoModel


+ (NSDictionary *)objectClassInArray{
    return @{@"stories" : [DianYingRiBaoStoriesModel class]};
}
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"desc":@"description"};
}
@end
@implementation DianYingRiBaoStoriesModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


