//
//  YongHuTuiJianRBViewModel.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "YongHuTuiJianRBViewModel.h"

@implementation YongHuTuiJianRBViewModel
- (NSString *)getDataStr{
    return @"12";
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [RiChangXinLiNetManager getYongHuTuiJianRBStr:self.getDataStr CompletionHandle:^(YongHuTuiJianRBModel *model, NSError *error) {
        self.YHTJRBModel = model;
        DDLogVerbose(@"self.YHTJRBModel.image%@",self.YHTJRBModel.image);
        self.topURL = [NSURL URLWithString:self.YHTJRBModel.image];
        DDLogVerbose(@"self.top%@",self.topURL);
//        DDLogVerbose(@"self.YHTJRBModel.image%@",self.YHTJRBModel);
        [self.dataArr removeAllObjects];
        [self.dataArr addObjectsFromArray:model.stories];
        completionHandle(error);
    }];
}
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
-(YongHuTuiJianRBStoriesModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
/** 题目 */
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRow:row].title;
}
/** 图片URL */
-(NSURL *)imageURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self modelForRow:row].images[0]]];
}

/** 是否存在图片 */
-(BOOL)isexistImage:(NSInteger)row{
    return [self modelForRow:row].images;
}
//-(NSURL *)topURL{
//    NSLog(@"topURL:%@",self.YHTJRBModel.image);
//
//    return [NSURL URLWithString:self.YHTJRBModel.image];
//}
- (NSURL *)topURL{
    NSLog(@"self：：%@",self.YHTJRBModel.image);

    return [NSURL URLWithString:self.YHTJRBModel.image];
}
-(NSURL *)IDForRow:(NSInteger)row{
    NSString *path = [NSString stringWithFormat:@"http://daily.zhihu.com/story/%ld",[self modelForRow:row].ID];
    return [NSURL URLWithString:path];
}
@end
