//
//  DianYingRiBaoViewModel.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DianYingRiBaoViewModel.h"

@implementation DianYingRiBaoViewModel
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [RiChangXinLiNetManager getDianYingRiBaoStr:self.getDataStr CompletionHandle:^(RiChangXinLiXueModel *model, NSError *error) {
        if ([self.getDataStr isEqualToString:@"3"]) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.stories];
        self.LasterID = model.stories.lastObject.ID;
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.getDataStr = @"3";
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.getDataStr = [NSString stringWithFormat:@"3/before/%ld",self.LasterID];
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (NSInteger)rowNumber{
    return self.dataArr.count;
}

-(RCXLXStoriesModel *)modelForRor:(NSInteger)row{
    return self.dataArr[row];
}

/** 题目 */
-(NSString *)titleForRow:(NSInteger)row{
    return [self modelForRor:row].title;
}
/** 图片URL */
-(NSURL *)imageURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self modelForRor:row].images[0]]];
}

/** 是否存在图片 */
-(BOOL)isexistImage:(NSInteger)row{
    return [self modelForRor:row].images;
}
-(NSURL *)IDForRow:(NSInteger)row{
    NSString *path = [NSString stringWithFormat:@"http://daily.zhihu.com/story/%ld",[self modelForRor:row].ID];
    return [NSURL URLWithString:path];
}
@end
