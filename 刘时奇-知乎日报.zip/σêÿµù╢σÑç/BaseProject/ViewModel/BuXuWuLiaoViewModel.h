//
//  BuXuWuLiaoViewModel.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RiChangXinLiNetManager.h"
@interface BuXuWuLiaoViewModel : BaseViewModel
@property(nonatomic)NSInteger rowNumber;
@property(nonatomic,strong)NSString *getDataStr;
/** 题目 */
-(NSString *)titleForRow:(NSInteger)row;
/** 是否存在图片 */
-(BOOL)isexistImage:(NSInteger)row;
/** 图片URL */
-(NSURL *)imageURLForRow:(NSInteger)row;
@property(nonatomic)NSInteger LasterID;
-(NSURL *)IDForRow:(NSInteger)row;
@end
