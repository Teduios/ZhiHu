//
//  YongHuTuiJianRBViewModel.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RiChangXinLiNetManager.h"
@interface YongHuTuiJianRBViewModel : BaseViewModel
@property(nonatomic)NSInteger rowNumber;
@property(nonatomic,strong)NSString *getDataStr;
@property(nonatomic,strong)NSURL *topURL;
/** 题目 */
-(NSString *)titleForRow:(NSInteger)row;
/** 是否存在图片 */
-(BOOL)isexistImage:(NSInteger)row;
/** 图片URL */
-(NSURL *)imageURLForRow:(NSInteger)row;
//-(NSURL *)topURL;
@property(nonatomic,strong)YongHuTuiJianRBModel *YHTJRBModel;
-(NSURL *)IDForRow:(NSInteger)row;
@end
