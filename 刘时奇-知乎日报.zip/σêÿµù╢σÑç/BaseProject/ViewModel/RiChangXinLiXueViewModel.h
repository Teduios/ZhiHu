//
//  RiChangXinLiXueViewModel.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RiChangXinLiNetManager.h"
@interface RiChangXinLiXueViewModel : BaseViewModel

@property(nonatomic)NSInteger rowNumber;
@property(nonatomic,strong)NSString *getDataStr;
/** 题目 */
-(NSString *)titleForRow:(NSInteger)row;
/** 是否存在图片 */
-(BOOL)isexistImage:(NSInteger)row;
/** 图片URL */
-(NSURL *)imageURLForRow:(NSInteger)row;
-(NSURL *)IDForRow:(NSInteger)row;
@property(nonatomic)NSInteger LasterID;


@end
