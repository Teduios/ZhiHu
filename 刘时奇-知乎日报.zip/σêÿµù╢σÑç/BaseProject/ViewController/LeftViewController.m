//
//  LeftViewController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LeftViewController.h"
#import "ViewController.h"
#import "RCXLXViewController.h"
#import "YHTJRBViewController.h"
#import "DianYingRiBaoViewController.h"
#import "BuXuWuLiaoController.h"
#import "SheJiRiBaoController.h"
@interface LeftViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UIView *topView;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *backView;
@property(nonatomic,strong)NSArray *dataArr;
@end

@implementation LeftViewController
- (NSArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSArray new];
        _dataArr = @[@"日常心里",@"用户推荐日报",@"电影日报",@"不许无聊",@"设计日报",@"大公司日报",@"财经日报",@"互联网安全",@"开始游戏",@"音乐日报",@"动漫日报",@"体育日报"];
    }
    return _dataArr;
}

- (UIView *)backView{
    if (!_backView) {
        _backView = [UIView new];
        //450.250   275.375
        //        _topView.frame = CGRectMake(0, 0, kWindowW, kWindowW*0.73);
        _backView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_backView];
        [_backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.73, kWindowH*0.13));
        }];
//        离线
        UIButton *LXImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [LXImageBtn setBackgroundImage:[UIImage imageNamed:@"Menu_Download"] forState:UIControlStateNormal];
        [self.backView addSubview:LXImageBtn];
        [LXImageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kWindowW *0.05);
            make.bottom.mas_equalTo(-kWindowW *0.05);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.09, kWindowW*0.09));
            
        }];
        UIButton *LXTitle = [UIButton buttonWithType:UIButtonTypeCustom];
        [LXTitle setTitle:@"离线" forState:UIControlStateNormal];
        LXTitle.titleLabel.textColor = [UIColor whiteColor];
        [self.backView addSubview:LXTitle];
        [LXTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(LXImageBtn.mas_right).mas_equalTo(kWindowW *0.04);
            make.centerY.mas_equalTo(LXImageBtn);
        }];
//        白天
        UIButton *BTImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [BTImageBtn setBackgroundImage:[UIImage imageNamed:@"Menu_Day"] forState:UIControlStateNormal];
        [self.backView addSubview:BTImageBtn];
        [BTImageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(LXTitle.mas_right).mas_equalTo(kWindowW*0.1);
//            make.bottom.mas_equalTo(-20);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.09, kWindowW*0.09));
            make.centerY.mas_equalTo(LXImageBtn);

            
        }];
        UIButton *BTTitle = [UIButton buttonWithType:UIButtonTypeCustom];
        [BTTitle setTitle:@"白天" forState:UIControlStateNormal];
        BTTitle.titleLabel.textColor = [UIColor whiteColor];
        [self.backView addSubview:BTTitle];
        [BTTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(BTImageBtn.mas_right).mas_equalTo(kWindowW *0.04);
            make.centerY.mas_equalTo(BTImageBtn);
        }];

    }
    return _backView;
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate =self;
        _tableView.dataSource = self;
        _tableView.estimatedRowHeight = 44;
//        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.topView.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(0);
            make.bottom.mas_equalTo(self.backView.mas_top);
            make.width.mas_equalTo(kWindowW*0.73);
//            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
- (UIView *)topView{
    if (!_topView) {
        _topView = [UIView new];
        //450.250   275.375
//        _topView.frame = CGRectMake(0, 0, kWindowW, kWindowW*0.73);
//        _topView.backgroundColor = [UIColor redColor];
        [self.view addSubview:_topView];
        [_topView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.73, kWindowH*0.25));
        }];
        UIButton *imageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [imageBtn setBackgroundImage:[UIImage imageNamed:@"Account_Avatar"] forState:UIControlStateNormal];
        imageBtn.layer.cornerRadius = kWindowW *0.06;
        [imageBtn.layer setMasksToBounds:YES];
        
        [self.topView addSubview:imageBtn];
        [imageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kWindowW *0.05);
            make.top.mas_equalTo(kWindowW *0.1);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.15, kWindowW*0.15));
        }];
        UIButton *nameBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [nameBtn setTitle:@"请登录" forState:UIControlStateNormal];
        nameBtn.titleLabel.font = [UIFont systemFontOfSize:kWindowW *0.05];
        [_topView addSubview:nameBtn];
        [nameBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(imageBtn.mas_right).mas_equalTo(kWindowW *0.04);
            make.centerY.mas_equalTo(imageBtn);
        }];
        UIButton *imageIV0 = [UIButton buttonWithType:UIButtonTypeCustom];
//        imageIV0.image = [UIImage imageNamed:@"Menu_Icon_Collect"];
        [imageIV0 setBackgroundImage:[UIImage imageNamed:@"Menu_Icon_Collect"] forState:UIControlStateNormal];
        [self.topView addSubview:imageIV0];
        [imageIV0 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kWindowW *0.05);
            make.top.mas_equalTo(imageBtn.mas_bottom).mas_equalTo(kWindowW *0.06);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.07, kWindowW*0.07));
        }];
        UIButton *SCBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [SCBtn setTitle:@"收藏" forState:UIControlStateNormal];
        SCBtn.titleLabel.font = [UIFont systemFontOfSize:kWindowW*0.03];
        [self.topView addSubview:SCBtn];
        [SCBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(imageIV0.mas_bottom).mas_equalTo(0);
            make.centerX.mas_equalTo(imageIV0);
        }];
//        消息
        UIButton *imageIV1 = [UIButton buttonWithType:UIButtonTypeCustom];
        //        imageIV0.image = [UIImage imageNamed:@"Menu_Icon_Collect"];
        [imageIV1 setBackgroundImage:[UIImage imageNamed:@"Menu_Icon_Message"] forState:UIControlStateNormal];
        [self.topView addSubview:imageIV1];
        [imageIV1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(imageIV0.mas_right).mas_equalTo(kWindowW*0.15);
//            make.top.mas_equalTo(imageBtn.mas_bottom).mas_equalTo(25);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.07, kWindowW*0.07));
            make.centerY.mas_equalTo(imageIV0);
        }];
        UIButton *XXBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [XXBtn setTitle:@"收藏" forState:UIControlStateNormal];
        XXBtn.titleLabel.font = [UIFont systemFontOfSize:kWindowW*0.03];
        [self.topView addSubview:XXBtn];
        [XXBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(imageIV1.mas_bottom).mas_equalTo(0);
            make.centerX.mas_equalTo(imageIV1);
        }];
//        设置
        UIButton *imageIV2 = [UIButton buttonWithType:UIButtonTypeCustom];
        //        imageIV0.image = [UIImage imageNamed:@"Menu_Icon_Collect"];
        [imageIV2 setBackgroundImage:[UIImage imageNamed:@"Menu_Icon_Setting"] forState:UIControlStateNormal];
        [self.topView addSubview:imageIV2];
        [imageIV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(imageIV1.mas_right).mas_equalTo(kWindowW*0.15);
            //            make.top.mas_equalTo(imageBtn.mas_bottom).mas_equalTo(25);
            make.size.mas_equalTo(CGSizeMake(kWindowW*0.07, kWindowW*0.07));
            make.centerY.mas_equalTo(imageIV1);
        }];
        UIButton *SZBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [SZBtn setTitle:@"设置" forState:UIControlStateNormal];
        SZBtn.titleLabel.font = [UIFont systemFontOfSize:kWindowW*0.03];
        [self.topView addSubview:SZBtn];
        [SZBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(imageIV2.mas_bottom).mas_equalTo(0);
            make.centerX.mas_equalTo(imageIV2);
        }];

    }
    return _topView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self topView];
    [self.tableView reloadData];
    // Do any additional setup after loading the view.
//    self.view.backgroundColor = [UIColor greenSeaColor];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    return self.dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"Cell"];
    }
    if (indexPath.section == 0) {
        cell.textLabel.text = @"首页";
        cell.backgroundColor=[UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.textLabel.textColor = [UIColor whiteColor];
        return cell;
    }
    cell.textLabel.text = self.dataArr[indexPath.row];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
    [cell.contentView addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(0);
        make.centerY.mas_equalTo(0);
    }];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        [self.sideMenuViewController setContentViewController:[ViewController standardNavi] animated:YES];
        [self.sideMenuViewController hideMenuViewController];
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
        [self.sideMenuViewController setContentViewController:[RCXLXViewController sharedNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 1) {
            [self.sideMenuViewController setContentViewController:[YHTJRBViewController standardNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 2) {
            [self.sideMenuViewController setContentViewController:[DianYingRiBaoViewController sharedNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 3) {
            [self.sideMenuViewController setContentViewController:[BuXuWuLiaoController sharedBuXuWuLiaoNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 4) {
            [self.sideMenuViewController setContentViewController:[SheJiRiBaoController sharedNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
