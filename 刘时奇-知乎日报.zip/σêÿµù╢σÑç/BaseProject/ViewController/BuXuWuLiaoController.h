//
//  BuXuWuLiaoController.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuXuWuLiaoController : UIViewController
+(UINavigationController *)sharedBuXuWuLiaoNavi;
@end
