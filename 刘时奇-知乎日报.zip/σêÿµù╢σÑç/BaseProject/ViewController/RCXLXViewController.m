//
//  RCXLXViewController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RCXLXViewController.h"
#import "RiChangXinLiXueViewModel.h"
#import "IndexCell.h"
#import "WebViewController.h"
//#import "UINavigationBar+Awesome.h"
#define NAVBAR_CHANGE_POINT 50
@interface RCXLXViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)RiChangXinLiXueViewModel *RCXLXVM;
@end

@implementation RCXLXViewController
+(UINavigationController *)sharedNavi{
    static UINavigationController *Navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        RCXLXViewController *vc = [RCXLXViewController new];
        Navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return Navi;
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[IndexCell class] forCellReuseIdentifier:@"IndexCell"];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:self.tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
- (RiChangXinLiXueViewModel *)RCXLXVM{
    if (!_RCXLXVM) {
        _RCXLXVM = [RiChangXinLiXueViewModel new];
    }
    return _RCXLXVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addMenuItemToVC:self];
    self.title = @"日常心里学";
    

//    self.navigationController.title = @"日常心里学";
    // Do any additional setup after loading the view.
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.RCXLXVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.RCXLXVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.RCXLXVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.RCXLXVM isexistImage:indexPath.row]) {
        IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IndexCell"];
        cell.titleLb.text = [self.RCXLXVM titleForRow:indexPath.row];
        [cell.imageIV.imageView setImageWithURL:[self.RCXLXVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.textLabel.text = [self.RCXLXVM titleForRow:indexPath.row];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (![self.RCXLXVM isexistImage:indexPath.row]) {
        return 44;
    }
    return UITableViewAutomaticDimension;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WebViewController *vc = [[WebViewController alloc]initWithURL:[self.RCXLXVM IDForRow:indexPath.row]];
    //    vc.url = ;
    NSLog(@"%@",vc.url);
    NSLog(@"%@",self.navigationController);
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    UIColor * color = [UIColor colorWithRed:0/255.0 green:175/255.0 blue:240/255.0 alpha:1];
//    CGFloat offsetY = scrollView.contentOffset.y;
//    if (offsetY > NAVBAR_CHANGE_POINT) {
//        CGFloat alpha = MIN(1, 1 - ((NAVBAR_CHANGE_POINT + 64 - offsetY) / 64));
//        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:alpha]];
//    } else {
//        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:0]];
//    }
//}
//
//- (void)viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:YES];
//    self.tableView.delegate = self;
//    [self scrollViewDidScroll:self.tableView];
//    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
//}
//
//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    self.tableView.delegate = nil;
//    [self.navigationController.navigationBar lt_reset];
//}

@end
