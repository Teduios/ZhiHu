//
//  WebNextViewController.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebNextViewController : UIViewController
- (id)initWithRequest:(NSURLRequest *)request;
@property(nonatomic,strong) NSURLRequest *request;
@end
