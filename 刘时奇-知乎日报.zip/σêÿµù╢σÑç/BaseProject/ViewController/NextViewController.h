//
//  NextViewController.h
//  BaseProject
//
//  Created by apple-jd09 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextViewController : UIViewController
@property(nonatomic)NSInteger ID;
@end
