//
//  SheJiRiBaoController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SheJiRiBaoController.h"
#import "INBPullToRefreshView.h"
#import "SheJiRiBaoViewModel.h"
#import "IndexCell.h"
#import "WebViewController.h"
@interface SheJiRiBaoController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)INBPullToRefreshView *refreshView;
@property(nonatomic,strong)SheJiRiBaoViewModel *SheJIRiBaoVM;
@property(nonatomic,strong)NSURL *topURL;
@end

@implementation SheJiRiBaoController

- (SheJiRiBaoViewModel *)SheJIRiBaoVM{
    if (!_SheJIRiBaoVM) {
        _SheJIRiBaoVM = [SheJiRiBaoViewModel new];
    }
    return _SheJIRiBaoVM;
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[IndexCell class] forCellReuseIdentifier:@"IndexCell"];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:self.tableView];
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
+(UINavigationController *)sharedNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        SheJiRiBaoController *vc = [SheJiRiBaoController new];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设计日报";
    [Factory addMenuItemToVC:self];
    // Do any additional setup after loading the view.
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.SheJIRiBaoVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            self.topURL = self.SheJIRiBaoVM.topURL;
            if (self.topURL) {
                self.refreshView = [self addPullToRefreshWithHeight:64 url:self.SheJIRiBaoVM.topURL tableView:self.tableView actoinHandler:^(INBPullToRefreshView *view) {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        if([view respondsToSelector:@selector(stopAnimation)]) {
                            [view performSelector:@selector(stopAnimation)];
                        }
                    });
                }];
            }
            [self.tableView reloadData];
        }];
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.SheJIRiBaoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];

    }];
    [self.tableView.mj_header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.SheJIRiBaoVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.SheJIRiBaoVM isexistImage:indexPath.row]) {
        IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IndexCell"];
        cell.titleLb.text = [self.SheJIRiBaoVM titleForRow:indexPath.row];
        [cell.imageIV.imageView setImageWithURL:[self.SheJIRiBaoVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.textLabel.text = [self.SheJIRiBaoVM titleForRow:indexPath.row];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
//    INBPullToRefreshView *refreshView;

    
//    self.refreshView.pullIndicatorView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"reload.png"]];
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WebViewController *vc = [[WebViewController alloc]initWithURL:[self.SheJIRiBaoVM IDForRow:indexPath.row]];
    //    vc.url = ;
    NSLog(@"%@",vc.url);
    NSLog(@"%@",self.navigationController);
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
