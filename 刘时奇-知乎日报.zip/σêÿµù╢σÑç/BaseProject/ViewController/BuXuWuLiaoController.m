//
//  BuXuWuLiaoController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BuXuWuLiaoController.h"
#import "IndexCell.h"
#import "BuXuWuLiaoViewModel.h"
#import "WebViewController.h"
@interface BuXuWuLiaoController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)BuXuWuLiaoViewModel *BuXuWuLiaoVM;
@end

@implementation BuXuWuLiaoController
- (BuXuWuLiaoViewModel *)BuXuWuLiaoVM{
    if (!_BuXuWuLiaoVM) {
        _BuXuWuLiaoVM = [BuXuWuLiaoViewModel new];
    }
    return _BuXuWuLiaoVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[IndexCell class] forCellReuseIdentifier:@"IndexCell"];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:self.tableView];
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
+(UINavigationController *)sharedBuXuWuLiaoNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        BuXuWuLiaoController *vc = [[BuXuWuLiaoController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addMenuItemToVC:self];
    self.title =@"不许无聊";
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.BuXuWuLiaoVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.BuXuWuLiaoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.BuXuWuLiaoVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.BuXuWuLiaoVM isexistImage:indexPath.row]) {
        IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IndexCell"];
        cell.titleLb.text = [self.BuXuWuLiaoVM titleForRow:indexPath.row];
        [cell.imageIV.imageView setImageWithURL:[self.BuXuWuLiaoVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.textLabel.text = [self.BuXuWuLiaoVM titleForRow:indexPath.row];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WebViewController *vc = [[WebViewController alloc]initWithURL:[self.BuXuWuLiaoVM IDForRow:indexPath.row]];
    //    vc.url = ;
    NSLog(@"%@",vc.url);
    NSLog(@"%@",self.navigationController);
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
