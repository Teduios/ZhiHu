//
//  DianYingRiBaoViewController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DianYingRiBaoViewController.h"
#import "DianYingRiBaoViewModel.h"
#import "MyCollectionViewCell.h"
#import "DianYingRiBaoCell.h"
#import "WebViewController.h"
@interface DianYingRiBaoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)DianYingRiBaoViewModel *DianYingRiBaoVM;
@property(nonatomic,strong)UICollectionView *collectionView;
@end

@implementation DianYingRiBaoViewController
//- (UICollectionView *)collectionView{
//    if (!_collectionView) {
//        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
//        [_collectionView registerClass:[MyCollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];
//        _collectionView.delegate = self;
//        _collectionView.dataSource = self;
//        [self.view addSubview:self.collectionView];
//        [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.edges.mas_equalTo(0);
//        }];
//    }
//    return _collectionView;
//}
- (DianYingRiBaoViewModel *)DianYingRiBaoVM{
    if (!_DianYingRiBaoVM) {
        _DianYingRiBaoVM = [DianYingRiBaoViewModel new];
    }
    return _DianYingRiBaoVM;
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:self.tableView];
        [_tableView registerClass:[DianYingRiBaoCell class] forCellReuseIdentifier:@"DCell"];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
+(UINavigationController *)sharedNavi{
    static UINavigationController *Navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        DianYingRiBaoViewController *vc = [DianYingRiBaoViewController new];
        Navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return Navi;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影日报";
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.DianYingRiBaoVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.DianYingRiBaoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    // Do any additional setup after loading the view.
//    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        [self.DianYingRiBaoVM refreshDataCompletionHandle:^(NSError *error) {
//            [self.collectionView.mj_header endRefreshing];
//            [self.collectionView reloadData];
//        }];
//    }];
//    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
//        [self.DianYingRiBaoVM getMoreDataCompletionHandle:^(NSError *error) {
//            [self.collectionView.mj_footer endRefreshing];
//            [self.collectionView reloadData];
//        }];
//    }];
//    [self.collectionView.mj_header beginRefreshing];
}



//- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
//    return self.DianYingRiBaoVM.rowNumber;
//}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
//- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
//    MyCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
//    [cell.ImageIV0.imageView setImageWithURL:[self.DianYingRiBaoVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
//    cell.TitleLb.text = [self.DianYingRiBaoVM titleForRow:indexPath.row];
//    
//    return cell;
//}
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
//    return CGSizeMake(kWindowW, kWindowW*0.68);
//}
//- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
//    return UIEdgeInsetsMake(10, 10, 10, 10);
//}
//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
//    return 10;
//}
//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
//    return 10;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.DianYingRiBaoVM.rowNumber;
}
kRemoveCellSeparator
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.DianYingRiBaoVM isexistImage:indexPath.row]) {
        DianYingRiBaoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DCell"];
        cell.titleLb.text = [self.DianYingRiBaoVM titleForRow:indexPath.row];
        [cell.imageIV.imageView setImageWithURL:[self.DianYingRiBaoVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
        return cell;
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.textLabel.text = [self.DianYingRiBaoVM titleForRow:indexPath.row];
    cell.textLabel.numberOfLines = 0;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (![self.DianYingRiBaoVM isexistImage:indexPath.row]) {
        return 44;
    }
    return UITableViewAutomaticDimension;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WebViewController *vc = [[WebViewController alloc]initWithURL:[self.DianYingRiBaoVM IDForRow:indexPath.row]];
    //    vc.url = ;
    NSLog(@"%@",vc.url);
    NSLog(@"%@",self.navigationController);
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
