//
//  YHTJRBViewController.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "YHTJRBViewController.h"
#import "YongHuTuiJianRBViewModel.h"
#import "IndexCell.h"
#import "UINavigationBar+Awesome.h"
#import "WebViewController.h"
#define kWindowHeight 300.0f
#define kImageHeight 400.0f
#define NAVBAR_CHANGE_POINT 50
@interface YHTJRBViewController ()<UITableViewDataSource, UITableViewDelegate>
{
    CGFloat _animateFactor;
}
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIScrollView *scrollView;
@property(nonatomic,strong)YongHuTuiJianRBViewModel *YHTJRBVM;
@end

@implementation YHTJRBViewController
- (YongHuTuiJianRBViewModel *)YHTJRBVM{
    if (!_YHTJRBVM) {
        _YHTJRBVM = [YongHuTuiJianRBViewModel new];
    }
    return _YHTJRBVM;
}
+(UIViewController *)standardNavi{
    static YHTJRBViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
         vc = [YHTJRBViewController new];
//        Navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return vc;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"用户推荐日报";
    [Factory addMenuItemToVC:self];
    [self.navigationController.navigationBar lt_setBackgroundColor:[UIColor clearColor]];
    self.scrollView.frame = CGRectMake(0,kWindowHeight - kImageHeight+(kImageHeight-kWindowHeight)/2.0f, self.view.frame.size.width, kImageHeight - kWindowHeight + self.view.frame.size.height);
    self.tableView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.YHTJRBVM getDataFromNetCompleteHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView.mj_header beginRefreshing];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (!section) {
        return 1;
    }
    return self.YHTJRBVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellReuseIdentifier   = @"cell";
    static NSString *windowReuseIdentifier = @"clean";
    
    UITableViewCell *cell = nil;
    
    if (indexPath.section == 0) {
        cell = [tableView dequeueReusableCellWithIdentifier:windowReuseIdentifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:windowReuseIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    else
    {
        if ([self.YHTJRBVM isexistImage:indexPath.row]) {
            IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IndexCell"];
            [cell.imageIV.imageView setImageWithURL:[self.YHTJRBVM imageURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"Account_Avatar"]];
            cell.titleLb.text = [self.YHTJRBVM titleForRow:indexPath.row];
            return cell;
        }
        cell = [tableView dequeueReusableCellWithIdentifier:cellReuseIdentifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellReuseIdentifier];
            cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        }
        cell.textLabel.text = [self.YHTJRBVM titleForRow:indexPath.row];
        cell.textLabel.numberOfLines = 0;
    }
    return cell;
}


#pragma mark - UITableViewDelegate

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if(indexPath.section == 0){
//        return kWindowHeight;
//    }
//    return 44;
//}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        return kWindowHeight;
    }
    return UITableViewAutomaticDimension;
}

#pragma mark - UIScrollViewDelegate
- (void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self updateOffsets];
}

- (void)updateOffsets {
    CGFloat yOffset   = _tableView.contentOffset.y;
    CGFloat threshold = kImageHeight - kWindowHeight;
    
    if (yOffset > -threshold && yOffset < 0) {
        
        _scrollView.contentOffset = CGPointMake(0.0, floorf(yOffset / 2.0));
        
    } else if (yOffset < 0) {
        
        _scrollView.contentOffset = CGPointMake(0.0, yOffset + floorf(threshold / 2.0));
        
    } else {
        
        _scrollView.contentOffset = CGPointMake(0.0, yOffset);
        
    }
#warning 加入放大效果
    //    _animateFactor = -(_tableView.contentOffset.y)*0.03;
    //
    //    ((UIScrollView *)[_scrollView viewWithTag:9999]).transform = CGAffineTransformMakeScale(_animateFactor < 1.0 ? 1.0 : _animateFactor,
    //                                                         _animateFactor < 1.0 ? 1.0 : _animateFactor);
    
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] init];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[IndexCell class] forCellReuseIdentifier:@"IndexCell"];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_scrollView];
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.backgroundColor = [UIColor clearColor];
        imageView.frame = CGRectMake(0, 0, self.view.frame.size.width, kImageHeight);
        imageView.tag = 9999;
        imageView.clipsToBounds = YES;
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.image =[UIImage imageNamed:@"153c4cb468b766a8eea35fcab05c3da5.jpg"];
//        DDLogVerbose(@"imgaeview:%@",self.YHTJRBVM.topURL);
        [_scrollView addSubview:imageView];
    }
    return _scrollView;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WebViewController *vc = [[WebViewController alloc]initWithURL:[self.YHTJRBVM IDForRow:indexPath.row]];
    //    vc.url = ;
    NSLog(@"%@",vc.url);
    NSLog(@"%@",self.navigationController);
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    UIColor * color = [UIColor colorWithRed:0/255.0 green:175/255.0 blue:240/255.0 alpha:1];
//    CGFloat offsetY = scrollView.contentOffset.y;
//    if (offsetY > NAVBAR_CHANGE_POINT) {
//        CGFloat alpha = MIN(1, 1 - ((NAVBAR_CHANGE_POINT + 64 - offsetY) / 64));
//        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:alpha]];
//    } else {
//        [self.navigationController.navigationBar lt_setBackgroundColor:[color colorWithAlphaComponent:0]];
//    }
//    [self updateOffsets];
//}
//
//- (void)viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:YES];
//    self.tableView.delegate = self;
//    [self scrollViewDidScroll:self.tableView];
//    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
//    
//}
//
//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    self.tableView.delegate = nil;
//    [self.navigationController.navigationBar lt_reset];
//}


@end
