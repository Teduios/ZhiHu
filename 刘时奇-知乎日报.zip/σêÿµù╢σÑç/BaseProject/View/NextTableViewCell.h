//
//  NextTableViewCell.h
//  BaseProject
//
//  Created by apple-jd09 on 15/11/27.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface NextTableViewCell : UITableViewCell
@property(nonatomic,strong)TRImageView *imageIV;
@property(nonatomic,strong)UILabel *titleLb;
@property(nonatomic,strong)UILabel *bodyLb;
@property(nonatomic,strong)UILabel *bodyTitleLb;



@end



