//
//  IndexCell.h
//  BaseProject
//
//  Created by apple-jd09 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface IndexCell : UITableViewCell
@property(nonatomic,strong)TRImageView *imageIV;
@property(nonatomic,strong)UILabel *titleLb;


@end
