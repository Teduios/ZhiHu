//
//  MyCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyCollectionViewCell.h"

@implementation MyCollectionViewCell


- (TRImageView *)ImageIV0 {
    if(_ImageIV0 == nil) {
        _ImageIV0 = [[TRImageView alloc] init];
    }
    return _ImageIV0;
}

- (UILabel *)TitleLb {
    if(_TitleLb == nil) {
        _TitleLb = [[UILabel alloc] init];
        _TitleLb.numberOfLines = 0;
        _TitleLb.font = [UIFont systemFontOfSize:19];
    }
    return _TitleLb;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self.contentView addSubview:self.ImageIV0];
        [self.ImageIV0 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.mas_equalTo(0);
            make.bottom.mas_equalTo(self.TitleLb.mas_top);
        }];
        [self.contentView addSubview:self.TitleLb];
        [self.TitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.right.mas_equalTo(-5);
            make.left.mas_equalTo(5);
        }];
    }
    return self;
}

@end
