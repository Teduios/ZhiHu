//
//  DianYingRiBaoCell.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface DianYingRiBaoCell : UITableViewCell
@property(nonatomic,strong)TRImageView *imageIV;
@property(nonatomic,strong)UILabel *titleLb;
@end
