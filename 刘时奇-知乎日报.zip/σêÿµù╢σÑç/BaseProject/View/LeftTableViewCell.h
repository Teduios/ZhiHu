//
//  LeftTableViewCell.h
//  BaseProject
//
//  Created by apple-jd09 on 15/11/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftTableViewCell : UITableViewCell
@property(nonatomic,strong)UIButton *btn1;
@property(nonatomic,strong)UILabel *titleLb;
@end
