//
//  MyCollectionViewCell.h
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface MyCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)TRImageView *ImageIV0;
@property(nonatomic,strong)UILabel *TitleLb;


@end
