//
//  DianYingRiBaoCell.m
//  BaseProject
//
//  Created by apple-jd09 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DianYingRiBaoCell.h"

@implementation DianYingRiBaoCell
- (TRImageView *)imageIV {
    if(_imageIV == nil) {
        _imageIV = [[TRImageView alloc] init];
    }
    return _imageIV;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:19];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.imageIV];
        [self.imageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
//            make.right.mas_equalTo(0);
            //150..120
//            make.size.mas_equalTo(CGSizeMake(50, 50));
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(kWindowW*0.6);
//            make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowW*0.4));
            //            make.size.mas_equalTo(CGSizeMake(50, 50));
//            make.bottom.mas_equalTo(self.titleLb.mas_top);
        }];
        [self.contentView addSubview:self.titleLb];
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.right.mas_equalTo(-15);
            make.left.mas_equalTo(15);
            make.top.mas_equalTo(self.imageIV.mas_bottom).mas_equalTo(5);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
